// ferry_sim.h - общие структуры
// время считаем тактами (1 такт = 1 минута)
// машины хранятся по номеру (id), т.к. массив машин растет через realloc
#ifndef FERRY_SIM_H
#define FERRY_SIM_H

#include <stdbool.h>
#include <stddef.h>

#define LEFT 0
#define RIGHT 1
#define OTHER(b) (1 - (b))
#define UNLIMITED (-1)

// цвета для консоли (в лог-файл не пишем)
#define C_RED    "\033[1;31m"
#define C_GREEN  "\033[1;32m"
#define C_YELLOW "\033[1;33m"
#define C_CYAN   "\033[1;36m"
#define C_WHITE  "\033[1;37m"

enum { STRAT_FIFO, STRAT_LOOKAHEAD, STRAT_BALANCED };
enum { REFUSE_MASS, REFUSE_SLOTS, REFUSE_COUNT, REFUSE_KINDS };
typedef enum { DEP_FULL, DEP_TIMEOUT, DEP_BLOCKED, DEP_NO_MORE,
               DEP_BALANCED, DEP_EMPTY, DEP_KINDS } DepReason;
typedef enum { LOC_QUEUE, LOC_FERRY, LOC_DONE } CarLoc;
typedef enum { F_LOADING, F_RAMP_CLOSING, F_CROSSING, F_UNLOADING } FerryState;
typedef enum { D_WAIT, D_LOAD, D_DEPART } DispAction;

extern const char *const BANK[2];
extern const char *const BANK_G[2];
extern const char *const BANK_D[2];
extern const char *const BANK_P[2];
extern const char *const REFUSE_TXT[];
extern const char *const DEP_TXT[];
extern const char *const FSTATE_TXT[];

typedef struct {
    int id;
    int mass;           // кг
    int size;           // сколько мест занимает
    bool emergency;
    int bank;
    CarLoc loc;         // где сейчас: очередь, паром или уже перевезена
    int t_arrive, t_board, t_done;  // когда приехала, села на паром, выгрузилась
    int skipped;        // сколько раз ее пропустили (lookahead)
    int rides;          // сколько раз перевезли (должно быть не больше 1)
    int stamp;
} Car;

typedef struct { int *ids; int n, cap; } Queue;

typedef struct {
    int capacity_kg, slots, max_cars;
    int cars[2], initial[2];                // всего машин / сколько уже стоит в начале
    int mass_min, mass_max, size_max;       // масса (кг на одно место) и макс. размер
    int arr_min, arr_max;                   // через сколько тактов приезжает следующая
    int load_time, unload_time, cross_time, ramp_time, max_wait;
    int strategy, window, skip_limit;
    int emergency_pct, priority, aging_limit, starve_limit;
    int max_trips, max_time;                // ограничения по рейсам и времени (0 = нет)
    int delay_ms, seed, color, visual;
    char log_path[256];
} Config;

typedef struct {
    FerryState state;
    int bank;           // у какого берега стоит (в рейсе - откуда отплыл)
    int *on;
    int n, mass, slots;
    int cur_car;        // какую машину сейчас грузим/выгружаем (или -1)
    int timer;          // сколько тактов осталось до конца операции
    int wait;           // сколько стоим у берега с начала погрузки
    bool ramp_open;
    int trips;
} Ferry;

typedef struct { DispAction act; int car; DepReason reason; } Decision;

typedef struct {
    int trips, empty_trips, dep[DEP_KINDS], refusals[REFUSE_KINDS];
    int carried[2];
    long wait_sum[2]; int wait_n[2], wait_max[2];   // [0] обычные, [1] экстренные (ожидание)
    long fill_mass, fill_slots, fill_cars;
} Stats;

typedef struct {
    Config cfg;
    int now;
    Car *cars; int ncars, cars_cap;
    Queue q[2];
    int next_arr[2], gen[2];        // когда приедет следующая, сколько уже создано
    Ferry ferry;
    Stats st;
    int log_fd, use_color, events;  // лог-файл, цвет, сколько событий было в этом такте
    int delivered, total;           // перевезено, всего (UNLIMITED если без ограничения)
    int stamp, failed;
    const char *stop;               // причина остановки (NULL пока работаем)
} World;

#define CAR(w, id) (&(w)->cars[(id) - 1])

// log.c
void log_open(World *w);
void log_close(World *w);
void logw(World *w, const char *color, const char *fmt, ...);
void logr(World *w, const char *color, const char *fmt, ...);
// config.c
void config_defaults(Config *c);
int  config_load_file(Config *c, const char *path);
int  config_set(Config *c, const char *key, const char *val);
int  config_validate(const Config *c);
// car.c
int  car_spawn(World *w, int bank);
void car_str(const Car *c, char *buf, size_t n);
void queue_remove(Queue *q, int idx);
void arrivals_step(World *w);
bool more_coming(const World *w, int bank);
int  oldest_wait(const World *w, int bank);
// ferry.c
void ferry_init(World *w);
void ferry_step(World *w);
bool ferry_fits(const World *w, const Car *c, int *why);
void ferry_status(const World *w, char *buf, size_t n);
// dispatcher.c
Decision dispatcher_decide(World *w);
// stats.c
void check_invariants(World *w);
void draw_scene(World *w);
void stats_print(World *w);

#endif
